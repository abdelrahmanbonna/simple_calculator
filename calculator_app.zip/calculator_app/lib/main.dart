import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
        textTheme: const TextTheme(
          bodyMedium: TextStyle(
            fontSize: 35,
            color: Colors.white,
          ),
          bodyLarge: TextStyle(
            fontSize: 55,
            color: Colors.white,
          ),
        ),
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({
    super.key,
  });

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String equation = '', result = '';

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    var mediaQuery = MediaQuery.of(context);
    return Scaffold(
      backgroundColor: Colors.blueGrey,

      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            height: mediaQuery.padding.top + mediaQuery.size.height * 0.06,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  equation,
                  style: theme.textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  result,
                  style: theme.textTheme.bodyLarge,
                ),
              ],
            ),
          ),
          SizedBox(
            width: mediaQuery.size.width,
            height: mediaQuery.size.height * 0.7,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: CalculatorButton(
                          title: "AC",
                          backgourndColor: Colors.cyan,
                          textColor: Colors.white,
                        ),
                      ),
                      Expanded(
                          child: CalculatorButton(
                        title: "/",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "X",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "C",
                        backgourndColor: Colors.indigo,
                        textColor: Colors.white,
                      )),
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                          child: CalculatorButton(
                        title: "7",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "8",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "9",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "-",
                        backgourndColor: Colors.indigo,
                        textColor: Colors.white,
                      )),
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                          child: CalculatorButton(
                        title: "4",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "5",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "6",
                        backgourndColor: Colors.cyan,
                        textColor: Colors.white,
                      )),
                      Expanded(
                          child: CalculatorButton(
                        title: "+",
                        backgourndColor: Colors.indigo,
                        textColor: Colors.white,
                            onPressed: (){
                              setState(() {
                                if(!equation.contains("+"))
                                equation = "${equation}+";
                                else
                                  print("error");
                              });
                            },
                      )),
                    ],
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: 3,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: CalculatorButton(
                                      title: "1",
                                      backgourndColor: Colors.cyan,
                                      textColor: Colors.white,
                                      onPressed: () {
                                        setState(() {
                                          equation = "${equation}1";
                                        });
                                      },
                                    ),
                                  ),
                                  Expanded(
                                      child: CalculatorButton(
                                    title: "2",
                                    backgourndColor: Colors.cyan,
                                    textColor: Colors.white,
                                    onPressed: () {
                                      setState(() {
                                        equation = "${equation}2";
                                      });
                                    },
                                  )),
                                  Expanded(
                                      child: CalculatorButton(
                                    title: "3",
                                    backgourndColor: Colors.cyan,
                                    textColor: Colors.white,
                                    onPressed: () {
                                      setState(() {
                                        equation = "${equation}3";
                                      });
                                    },
                                  )),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                      child: CalculatorButton(
                                    title: ".",
                                    backgourndColor: Colors.cyan,
                                    textColor: Colors.white,
                                  )),
                                  Expanded(
                                      child: CalculatorButton(
                                    title: "0",
                                    backgourndColor: Colors.cyan,
                                    textColor: Colors.white,
                                  )),
                                  Expanded(
                                      child: CalculatorButton(
                                    title: "%",
                                    backgourndColor: Colors.cyan,
                                    textColor: Colors.white,
                                  )),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                          child: CalculatorButton(
                        title: "=",
                        backgourndColor: Colors.indigo,
                        textColor: Colors.white,
                            onPressed: (){
                          setState(() {
                            if(equation.contains("+")){
                              var number1 = equation.split("+").first;
                              var number2 = equation.split("+").last;

                              result = (int.parse(number1)+ int.parse(number2)).toString();
                            }
                          });
                            },
                      ))
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

// int double String Map

class CalculatorButton extends StatelessWidget {
  final String title;
  final Color backgourndColor, textColor;
  final void Function()? onPressed;

  const CalculatorButton({
    super.key,
    required this.title,
    required this.backgourndColor,
    required this.textColor,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        color: backgourndColor,
        child: Center(
          child: Text(
            title,
            style: theme.textTheme.bodyMedium!.copyWith(color: textColor),
          ),
        ),
      ),
    );
  }
}
